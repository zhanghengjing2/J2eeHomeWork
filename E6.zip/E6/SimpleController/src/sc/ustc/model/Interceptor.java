package sc.ustc.model;

public class Interceptor {

}
