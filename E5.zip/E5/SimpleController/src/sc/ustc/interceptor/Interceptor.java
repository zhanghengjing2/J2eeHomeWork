package sc.ustc.interceptor;

public class Interceptor {

}
