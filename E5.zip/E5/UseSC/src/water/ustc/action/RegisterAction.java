package water.ustc.action;

public class RegisterAction {

	public String handleRegister()
	{
		return "success";
	}
}
