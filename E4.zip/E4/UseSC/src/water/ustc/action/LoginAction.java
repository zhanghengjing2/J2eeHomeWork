package water.ustc.action;

public class LoginAction {

	public String handleLogin()
	{
		return "success";
//		return "failure";
	}
}
